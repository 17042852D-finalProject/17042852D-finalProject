$(document).ready(function(){
    if(!!$.cookie('login')){//has logged in
        
    }
});